﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Book_2
{
    public class Contact
    {
        public int ContactId { get; set; }
        public string ContactName { get; set; }
        public string ContactNumber { get; set; }
        public string ContactAddress { get; set; }
        public string ContactBirthday { get; set; }
        public string ContactEmail { get; set; }
        public byte[] ContactImage { get; set; }
    }
}
