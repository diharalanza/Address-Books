﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Address_Book_2
{
    public partial class Tree_Form : Form
    {
        public Tree_Form()
        {
            InitializeComponent();
            timer1.Start();
        }

        Label focus;
        int on = 1;
        int timer_in = 10;
        int main = 9;

        int y_pos = 68;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(on == 1)
            {
                t2.Text = (int.Parse(t2.Text) - 1).ToString();
                timer_in--;
            }
            else if(on == 0)
            {
                focus.Text = (int.Parse(focus.Text) - 1).ToString();
                timer_in--;
            }

            if (timer_in == 0)
            {
                timer_in = 10;
                on = 0;

                Label next = new Label();
                focus = next;
                next.Location = new System.Drawing.Point(367, y_pos);
               
                next.Text = "10";

                this.Controls.Add(next);

                Label nextMain = new Label();
                nextMain.Location = new System.Drawing.Point(203, y_pos);
                nextMain.Text = main.ToString();
                this.Controls.Add(nextMain);
                main--;
                y_pos += 30;

                if (main == -1)
                {
                    timer1.Stop();
                    focus.Text = "0";
                }

            }

        }
        
    }
}
