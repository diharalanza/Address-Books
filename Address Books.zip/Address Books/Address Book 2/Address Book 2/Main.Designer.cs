﻿
namespace Address_Book_2
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.results = new System.Windows.Forms.DataGridView();
            this.select_search = new System.Windows.Forms.ComboBox();
            this.search_bar = new System.Windows.Forms.TextBox();
            this.add = new System.Windows.Forms.Button();
            this.tree_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.results)).BeginInit();
            this.SuspendLayout();
            // 
            // results
            // 
            this.results.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.results.Location = new System.Drawing.Point(37, 59);
            this.results.Name = "results";
            this.results.RowTemplate.Height = 25;
            this.results.Size = new System.Drawing.Size(549, 225);
            this.results.TabIndex = 0;
            this.results.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.results_CellDoubleClick);
            // 
            // select_search
            // 
            this.select_search.ForeColor = System.Drawing.Color.Black;
            this.select_search.FormattingEnabled = true;
            this.select_search.Items.AddRange(new object[] {
            "Name",
            "Number",
            "Address",
            "Birthday",
            "E-Mail"});
            this.select_search.Location = new System.Drawing.Point(37, 21);
            this.select_search.Name = "select_search";
            this.select_search.Size = new System.Drawing.Size(163, 23);
            this.select_search.TabIndex = 1;
            this.select_search.Text = "Name";
            // 
            // search_bar
            // 
            this.search_bar.ForeColor = System.Drawing.Color.DimGray;
            this.search_bar.Location = new System.Drawing.Point(206, 21);
            this.search_bar.Name = "search_bar";
            this.search_bar.Size = new System.Drawing.Size(380, 23);
            this.search_bar.TabIndex = 2;
            this.search_bar.Text = "Search here";
            this.search_bar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.search_bar_KeyUp);
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.DarkCyan;
            this.add.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.add.ForeColor = System.Drawing.Color.Black;
            this.add.Location = new System.Drawing.Point(423, 295);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(163, 33);
            this.add.TabIndex = 3;
            this.add.Text = "Add Contact";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // tree_btn
            // 
            this.tree_btn.Location = new System.Drawing.Point(37, 301);
            this.tree_btn.Name = "tree_btn";
            this.tree_btn.Size = new System.Drawing.Size(75, 23);
            this.tree_btn.TabIndex = 4;
            this.tree_btn.Text = "Tree";
            this.tree_btn.UseVisualStyleBackColor = true;
            this.tree_btn.Click += new System.EventHandler(this.tree_btn_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 340);
            this.Controls.Add(this.tree_btn);
            this.Controls.Add(this.add);
            this.Controls.Add(this.search_bar);
            this.Controls.Add(this.select_search);
            this.Controls.Add(this.results);
            this.Name = "Main";
            this.Text = "Address Book";
            ((System.ComponentModel.ISupportInitialize)(this.results)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView results;
        private System.Windows.Forms.ComboBox select_search;
        private System.Windows.Forms.TextBox search_bar;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button tree_btn;
    }
}

