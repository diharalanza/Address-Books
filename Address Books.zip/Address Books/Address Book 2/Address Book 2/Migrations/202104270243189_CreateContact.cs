﻿namespace Address_Book_2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateContact : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Contacts",
                c => new
                    {
                        ContactId = c.Int(nullable: false, identity: true),
                        ContactName = c.String(),
                        ContactNumber = c.String(),
                        ContactAddress = c.String(),
                        ContactBirthday = c.String(),
                        ContactEmail = c.String(),
                    })
                .PrimaryKey(t => t.ContactId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Contacts");
        }
    }
}
