﻿namespace Address_Book_2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateContact2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Contacts", "ContactImage", c => c.Binary());
            DropColumn("dbo.Contacts", "CotactImage");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Contacts", "CotactImage", c => c.Binary());
            DropColumn("dbo.Contacts", "ContactImage");
        }
    }
}
