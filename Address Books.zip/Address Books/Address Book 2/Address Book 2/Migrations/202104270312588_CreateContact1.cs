﻿namespace Address_Book_2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateContact1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Contacts", "CotactImage", c => c.Binary());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Contacts", "CotactImage");
        }
    }
}
