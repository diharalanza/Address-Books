﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;

namespace Address_Book_2
{
    public class ContactContext : DbContext

    {
        public ContactContext()
        : base(@"Data Source=DIHARA;Initial Catalog=ContactContext;Integrated Security=True") { }

        public DbSet<Contact> Contacts { get; set; }
    }
}
