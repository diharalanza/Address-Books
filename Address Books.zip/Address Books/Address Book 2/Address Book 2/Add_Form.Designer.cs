﻿
namespace Address_Book_2
{
    partial class Add_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.add_name = new System.Windows.Forms.TextBox();
            this.add_email = new System.Windows.Forms.TextBox();
            this.add_year = new System.Windows.Forms.TextBox();
            this.add_addr = new System.Windows.Forms.TextBox();
            this.add_num = new System.Windows.Forms.TextBox();
            this.save_btn = new System.Windows.Forms.Button();
            this.add_month = new System.Windows.Forms.TextBox();
            this.add_day = new System.Windows.Forms.TextBox();
            this.add_photo = new System.Windows.Forms.PictureBox();
            this.browse_img = new System.Windows.Forms.Button();
            this.timer_add = new System.Windows.Forms.Timer(this.components);
            this.timer = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.add_photo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Birthday (dd/mm/yy):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "E-Mail:";
            // 
            // add_name
            // 
            this.add_name.Location = new System.Drawing.Point(76, 32);
            this.add_name.Name = "add_name";
            this.add_name.Size = new System.Drawing.Size(234, 23);
            this.add_name.TabIndex = 5;
            // 
            // add_email
            // 
            this.add_email.Location = new System.Drawing.Point(76, 148);
            this.add_email.Name = "add_email";
            this.add_email.Size = new System.Drawing.Size(234, 23);
            this.add_email.TabIndex = 6;
            // 
            // add_year
            // 
            this.add_year.Location = new System.Drawing.Point(241, 119);
            this.add_year.Name = "add_year";
            this.add_year.Size = new System.Drawing.Size(69, 23);
            this.add_year.TabIndex = 7;
            // 
            // add_addr
            // 
            this.add_addr.Location = new System.Drawing.Point(76, 90);
            this.add_addr.Name = "add_addr";
            this.add_addr.Size = new System.Drawing.Size(234, 23);
            this.add_addr.TabIndex = 8;
            // 
            // add_num
            // 
            this.add_num.Location = new System.Drawing.Point(76, 61);
            this.add_num.Name = "add_num";
            this.add_num.Size = new System.Drawing.Size(234, 23);
            this.add_num.TabIndex = 9;
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.save_btn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.save_btn.Location = new System.Drawing.Point(24, 190);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(286, 40);
            this.save_btn.TabIndex = 10;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // add_month
            // 
            this.add_month.Location = new System.Drawing.Point(190, 119);
            this.add_month.Name = "add_month";
            this.add_month.Size = new System.Drawing.Size(45, 23);
            this.add_month.TabIndex = 11;
            // 
            // add_day
            // 
            this.add_day.Location = new System.Drawing.Point(139, 119);
            this.add_day.Name = "add_day";
            this.add_day.Size = new System.Drawing.Size(45, 23);
            this.add_day.TabIndex = 12;
            // 
            // add_photo
            // 
            this.add_photo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.add_photo.Location = new System.Drawing.Point(345, 41);
            this.add_photo.Name = "add_photo";
            this.add_photo.Size = new System.Drawing.Size(130, 130);
            this.add_photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add_photo.TabIndex = 13;
            this.add_photo.TabStop = false;
            // 
            // browse_img
            // 
            this.browse_img.Location = new System.Drawing.Point(374, 177);
            this.browse_img.Name = "browse_img";
            this.browse_img.Size = new System.Drawing.Size(75, 23);
            this.browse_img.TabIndex = 14;
            this.browse_img.Text = "Browse";
            this.browse_img.UseVisualStyleBackColor = true;
            this.browse_img.Click += new System.EventHandler(this.browse_img_Click);
            // 
            // timer_add
            // 
            this.timer_add.Interval = 1000;
            this.timer_add.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer
            // 
            this.timer.AutoSize = true;
            this.timer.BackColor = System.Drawing.SystemColors.ControlDark;
            this.timer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.timer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.timer.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.timer.ForeColor = System.Drawing.Color.Black;
            this.timer.Location = new System.Drawing.Point(397, 203);
            this.timer.Name = "timer";
            this.timer.Size = new System.Drawing.Size(23, 32);
            this.timer.TabIndex = 15;
            this.timer.Text = "-";
            // 
            // Add_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 266);
            this.Controls.Add(this.timer);
            this.Controls.Add(this.browse_img);
            this.Controls.Add(this.add_photo);
            this.Controls.Add(this.add_day);
            this.Controls.Add(this.add_month);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.add_num);
            this.Controls.Add(this.add_addr);
            this.Controls.Add(this.add_year);
            this.Controls.Add(this.add_email);
            this.Controls.Add(this.add_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Add_Form";
            this.Text = "Add Contact";
            ((System.ComponentModel.ISupportInitialize)(this.add_photo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox add_name;
        private System.Windows.Forms.TextBox add_email;
        private System.Windows.Forms.TextBox add_year;
        private System.Windows.Forms.TextBox add_addr;
        private System.Windows.Forms.TextBox add_num;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.TextBox add_month;
        private System.Windows.Forms.TextBox add_day;
        private System.Windows.Forms.PictureBox add_photo;
        private System.Windows.Forms.Button browse_img;
        private System.Windows.Forms.Timer timer_add;
        private System.Windows.Forms.Label timer;
    }
}