﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Address_Book_2
{
    public partial class Edit_Form : Form
    {
        string path = @"Data Source=DIHARA;Initial Catalog=db1;Integrated Security=True";
        Main parent;
        SqlConnection con;
        string id;
        string bday;
        string imgloc;
        
        public Edit_Form(string[] data, MemoryStream i, Main f)
        {
            InitializeComponent();
            parent = f;

            con = new SqlConnection(path);

            id = data[0];

            edit_name.Text = data[1];
            edit_num.Text = data[2];
            edit_addr.Text = data[3];
            edit_photo.Image = new Bitmap(i);


            if (!String.IsNullOrWhiteSpace(data[4]))
            {
                string[] bday_vals = data[4].Split('/');

                edit_day.Text = bday_vals[0];
                edit_month.Text = bday_vals[1];
                edit_year.Text = bday_vals[2];
            }
            edit_email.Text = data[5];
        }

        public Edit_Form(string[] data, Main f)
        {
            InitializeComponent();
            parent = f;

            con = new SqlConnection(path);

            id = data[0];

            edit_name.Text = data[1];
            edit_num.Text = data[2];
            edit_addr.Text = data[3];

            if (!String.IsNullOrWhiteSpace(data[4]))
            {
                string[] bday_vals = data[4].Split('/');

                edit_day.Text = bday_vals[0];
                edit_month.Text = bday_vals[1];
                edit_year.Text = bday_vals[2];
            }
            edit_email.Text = data[5];
        }

        private void edit_img_Click(object sender, EventArgs e)
        {
            timer.ForeColor = Color.Green;
            timer.Text = "60";
            timer_edit.Start();

            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (open.ShowDialog() == DialogResult.OK)
            {
                imgloc = open.FileName.ToString();
                edit_photo.ImageLocation = imgloc;
            }
            timer.ForeColor = Color.Black;
            timer.Text = "-";
            timer_edit.Stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool save = true;

            //checks if all is blank
            if (String.IsNullOrWhiteSpace(edit_name.Text) && String.IsNullOrWhiteSpace(edit_num.Text) && String.IsNullOrWhiteSpace(edit_addr.Text) && (String.IsNullOrWhiteSpace(edit_day.Text) || String.IsNullOrWhiteSpace(edit_month.Text) || String.IsNullOrWhiteSpace(edit_year.Text)) && String.IsNullOrWhiteSpace(edit_email.Text))
            {
                MessageBox.Show("Please enter atleast one value.");
                save = false;
            }
            else
            {
                if ((long.TryParse(edit_day.Text, out _) == false || long.TryParse(edit_month.Text, out _) == false || long.TryParse(edit_year.Text, out _) == false) && (String.IsNullOrWhiteSpace(edit_day.Text) == false && String.IsNullOrWhiteSpace(edit_month.Text) == false && String.IsNullOrWhiteSpace(edit_year.Text) == false))
                {
                    MessageBox.Show("Enter a valid date1.");
                    save = false;
                }
                else if (String.IsNullOrWhiteSpace(edit_day.Text) == false && String.IsNullOrWhiteSpace(edit_month.Text) == false && String.IsNullOrWhiteSpace(edit_year.Text) == false)
                {
                    if ((int.Parse(edit_day.Text) > 31 || int.Parse(edit_day.Text) < 1) || (int.Parse(edit_month.Text) > 12 || int.Parse(edit_month.Text) < 1) || int.Parse(edit_year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date2.");
                        save = false;
                    }
                    else if ((int.Parse(edit_day.Text) > 29 || int.Parse(edit_day.Text) < 1) && (int.Parse(edit_month.Text) == 2) || int.Parse(edit_year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date3.");
                        save = false;
                    }
                }

                else if (String.IsNullOrWhiteSpace(edit_day.Text) == false || String.IsNullOrWhiteSpace(edit_month.Text) == false || String.IsNullOrWhiteSpace(edit_year.Text) == false)
                {
                    MessageBox.Show("Enter a valid date4.");
                    save = false;
                }
            }

            //number is typed in
            if (!(String.IsNullOrWhiteSpace(edit_num.Text)))
            {
                if (long.TryParse(edit_num.Text, out _) == false)
                {
                    MessageBox.Show("Enter a valid phone number.");
                    save = false;
                }
            }
            if (save == true)
            {
                if (String.IsNullOrWhiteSpace(edit_day.Text))
                {
                    bday = "";
                }
                else
                {
                    bday = int.Parse(edit_day.Text) + "/" + int.Parse(edit_month.Text) + "/" + int.Parse(edit_year.Text);
                }

                FileStream stream = new FileStream(imgloc, FileMode.Open, FileAccess.Read);

                using (ContactContext context = new ContactContext())
                {
                    Contact found = context.Contacts.Find(int.Parse(id));

                    found.ContactName = edit_name.Text;
                    found.ContactNumber = edit_num.Text;
                    found.ContactAddress = edit_addr.Text;
                    found.ContactBirthday = bday;
                    found.ContactEmail = edit_email.Text;
                    found.ContactImage = new BinaryReader(stream).ReadBytes((int)stream.Length);

                    context.SaveChanges();
                    MessageBox.Show("Contact updated.");
                    parent.displayAll();
                    this.Close();
                }
            }
        }

        private void del_btn_Click(object sender, EventArgs e)
        {
            using (ContactContext context = new ContactContext())
            {
                Contact found = context.Contacts.Find(int.Parse(id));
                context.Contacts.Remove(found);

                context.SaveChanges();
                MessageBox.Show("Contact deleted.");
                parent.displayAll();
                this.Close();
            }
        }

        private void timer_edit_Tick(object sender, EventArgs e)
        {
            timer.Text = (int.Parse(timer.Text) - 1).ToString();

            if (timer.Text == "30")
            {
                timer.ForeColor = Color.Yellow;
            }

            if (timer.Text == "10")
            {
                timer.ForeColor = Color.Red;
            }

            if (timer.Text == "0")
            {
                timer_edit.Stop();
            }
        }
    }
}
