﻿
namespace Address_Book_2
{
    partial class Edit_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.edit_name = new System.Windows.Forms.TextBox();
            this.edit_year = new System.Windows.Forms.TextBox();
            this.edit_addr = new System.Windows.Forms.TextBox();
            this.edit_num = new System.Windows.Forms.TextBox();
            this.edit_month = new System.Windows.Forms.TextBox();
            this.edit_day = new System.Windows.Forms.TextBox();
            this.edit_email = new System.Windows.Forms.TextBox();
            this.del_btn = new System.Windows.Forms.Button();
            this.update_btn = new System.Windows.Forms.Button();
            this.edit_photo = new System.Windows.Forms.PictureBox();
            this.edit_img = new System.Windows.Forms.Button();
            this.timer_edit = new System.Windows.Forms.Timer(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.edit_photo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Birthday (dd/mm/yy):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "E-Mail:";
            // 
            // edit_name
            // 
            this.edit_name.Location = new System.Drawing.Point(67, 28);
            this.edit_name.Name = "edit_name";
            this.edit_name.Size = new System.Drawing.Size(259, 23);
            this.edit_name.TabIndex = 5;
            // 
            // edit_year
            // 
            this.edit_year.Location = new System.Drawing.Point(256, 152);
            this.edit_year.Name = "edit_year";
            this.edit_year.Size = new System.Drawing.Size(70, 23);
            this.edit_year.TabIndex = 6;
            // 
            // edit_addr
            // 
            this.edit_addr.Location = new System.Drawing.Point(67, 110);
            this.edit_addr.Name = "edit_addr";
            this.edit_addr.Size = new System.Drawing.Size(259, 23);
            this.edit_addr.TabIndex = 7;
            // 
            // edit_num
            // 
            this.edit_num.Location = new System.Drawing.Point(67, 68);
            this.edit_num.Name = "edit_num";
            this.edit_num.Size = new System.Drawing.Size(259, 23);
            this.edit_num.TabIndex = 8;
            // 
            // edit_month
            // 
            this.edit_month.Location = new System.Drawing.Point(198, 152);
            this.edit_month.Name = "edit_month";
            this.edit_month.Size = new System.Drawing.Size(52, 23);
            this.edit_month.TabIndex = 9;
            // 
            // edit_day
            // 
            this.edit_day.Location = new System.Drawing.Point(140, 152);
            this.edit_day.Name = "edit_day";
            this.edit_day.Size = new System.Drawing.Size(52, 23);
            this.edit_day.TabIndex = 10;
            // 
            // edit_email
            // 
            this.edit_email.Location = new System.Drawing.Point(67, 194);
            this.edit_email.Name = "edit_email";
            this.edit_email.Size = new System.Drawing.Size(259, 23);
            this.edit_email.TabIndex = 11;
            // 
            // del_btn
            // 
            this.del_btn.BackColor = System.Drawing.Color.Red;
            this.del_btn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.del_btn.Location = new System.Drawing.Point(184, 234);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(142, 68);
            this.del_btn.TabIndex = 12;
            this.del_btn.Text = "Delete";
            this.del_btn.UseVisualStyleBackColor = false;
            this.del_btn.Click += new System.EventHandler(this.del_btn_Click);
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.update_btn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.update_btn.Location = new System.Drawing.Point(22, 234);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(142, 68);
            this.update_btn.TabIndex = 13;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // edit_photo
            // 
            this.edit_photo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.edit_photo.Location = new System.Drawing.Point(355, 68);
            this.edit_photo.Name = "edit_photo";
            this.edit_photo.Size = new System.Drawing.Size(140, 140);
            this.edit_photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.edit_photo.TabIndex = 14;
            this.edit_photo.TabStop = false;
            // 
            // edit_img
            // 
            this.edit_img.Location = new System.Drawing.Point(388, 214);
            this.edit_img.Name = "edit_img";
            this.edit_img.Size = new System.Drawing.Size(75, 23);
            this.edit_img.TabIndex = 15;
            this.edit_img.Text = "Browse";
            this.edit_img.UseVisualStyleBackColor = true;
            this.edit_img.Click += new System.EventHandler(this.edit_img_Click);
            // 
            // timer_edit
            // 
            this.timer_edit.Interval = 1000;
            this.timer_edit.Tick += new System.EventHandler(this.timer_edit_Tick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(406, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 15);
            this.label6.TabIndex = 16;
            // 
            // timer
            // 
            this.timer.AutoSize = true;
            this.timer.BackColor = System.Drawing.SystemColors.ControlDark;
            this.timer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.timer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.timer.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.timer.ForeColor = System.Drawing.Color.Black;
            this.timer.Location = new System.Drawing.Point(412, 240);
            this.timer.Name = "timer";
            this.timer.Size = new System.Drawing.Size(23, 32);
            this.timer.TabIndex = 17;
            this.timer.Text = "-";
            // 
            // Edit_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 323);
            this.Controls.Add(this.timer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.edit_img);
            this.Controls.Add(this.edit_photo);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.del_btn);
            this.Controls.Add(this.edit_email);
            this.Controls.Add(this.edit_day);
            this.Controls.Add(this.edit_month);
            this.Controls.Add(this.edit_num);
            this.Controls.Add(this.edit_addr);
            this.Controls.Add(this.edit_year);
            this.Controls.Add(this.edit_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Edit_Form";
            this.Text = "Edit or Delete Contact";
            ((System.ComponentModel.ISupportInitialize)(this.edit_photo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox edit_name;
        private System.Windows.Forms.TextBox edit_year;
        private System.Windows.Forms.TextBox edit_addr;
        private System.Windows.Forms.TextBox edit_num;
        private System.Windows.Forms.TextBox edit_month;
        private System.Windows.Forms.TextBox edit_day;
        private System.Windows.Forms.TextBox edit_email;
        private System.Windows.Forms.Button del_btn;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.PictureBox edit_photo;
        private System.Windows.Forms.Button edit_img;
        private System.Windows.Forms.Timer timer_edit;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label timer;
    }
}