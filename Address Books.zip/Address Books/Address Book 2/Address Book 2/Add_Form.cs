﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Address_Book_2
{
    public partial class Add_Form : Form
    {
        Main parent;
        string bday;
        string imgloc;
        public Add_Form(Main f)
        {
            InitializeComponent();
            parent = f;
        }

        private void browse_img_Click(object sender, EventArgs e)
        {
            timer.ForeColor = Color.Green;
            timer.Text = "60";
            timer_add.Start();

            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (open.ShowDialog() == DialogResult.OK)
            {
                imgloc = open.FileName.ToString();
                add_photo.ImageLocation = imgloc;
            }
            timer.ForeColor = Color.Black;
            timer.Text = "-";
            timer_add.Stop();
        }
        private void save_btn_Click(object sender, EventArgs e)
        {
            bool save = true;

            //checks if all is blank
            if (String.IsNullOrWhiteSpace(add_name.Text) && String.IsNullOrWhiteSpace(add_num.Text) && String.IsNullOrWhiteSpace(add_addr.Text) && (String.IsNullOrWhiteSpace(add_day.Text) || String.IsNullOrWhiteSpace(add_month.Text) || String.IsNullOrWhiteSpace(add_year.Text)) && String.IsNullOrWhiteSpace(add_email.Text))
            {
                MessageBox.Show("Please enter atleast one value.");
                save = false;
            }
            else
            {
                if ((long.TryParse(add_day.Text, out _) == false || long.TryParse(add_month.Text, out _) == false || long.TryParse(add_year.Text, out _) == false) && (String.IsNullOrWhiteSpace(add_day.Text) == false && String.IsNullOrWhiteSpace(add_month.Text) == false && String.IsNullOrWhiteSpace(add_year.Text) == false))
                {
                    MessageBox.Show("Enter a valid date1.");
                    save = false;
                }
                else if (String.IsNullOrWhiteSpace(add_day.Text) == false && String.IsNullOrWhiteSpace(add_month.Text) == false && String.IsNullOrWhiteSpace(add_year.Text) == false)
                {
                    if ((int.Parse(add_day.Text) > 31 || int.Parse(add_day.Text) < 1) || (int.Parse(add_month.Text) > 12 || int.Parse(add_month.Text) < 1) || int.Parse(add_year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date2.");
                        save = false;
                    }
                    else if ((int.Parse(add_day.Text) > 29 || int.Parse(add_day.Text) < 1) && (int.Parse(add_month.Text) == 2) || int.Parse(add_year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date3.");
                        save = false;
                    }
                }

                else if (String.IsNullOrWhiteSpace(add_day.Text) == false || String.IsNullOrWhiteSpace(add_month.Text) == false || String.IsNullOrWhiteSpace(add_year.Text) == false)
                {
                    MessageBox.Show("Enter a valid date4.");
                    save = false;
                }
            }

            //number is typed in
            if (!(String.IsNullOrWhiteSpace(add_num.Text)))
            {
                if (long.TryParse(add_num.Text, out _) == false)
                {
                    MessageBox.Show("Enter a valid phone number.");
                    save = false;
                }
            }
            if (save == true)
            {
                if (String.IsNullOrWhiteSpace(add_day.Text))
                {
                    bday = "";
                }
                else
                {
                    bday = int.Parse(add_day.Text) + "/" + int.Parse(add_month.Text) + "/" + int.Parse(add_year.Text);
                }

                FileStream stream = new FileStream(imgloc, FileMode.Open, FileAccess.Read);

                using (ContactContext context = new ContactContext())
                {
                    Contact newContact = new Contact()
                    {
                        ContactName = add_name.Text,
                        ContactNumber = add_num.Text,
                        ContactAddress = add_addr.Text,
                        ContactBirthday = bday,
                        ContactEmail = add_email.Text,
                        ContactImage = new BinaryReader(stream).ReadBytes((int)stream.Length)
                    };

                    context.Contacts.Add(newContact);
                    context.SaveChanges();
                    MessageBox.Show("Contact saved.");
                    parent.displayAll();
                    this.Close();
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer.Text = (int.Parse(timer.Text) - 1).ToString();
            
            if(timer.Text == "30")
            {
                timer.ForeColor = Color.Yellow;
            }

            if (timer.Text == "10")
            {
                timer.ForeColor = Color.Red;
            }

            if (timer.Text == "0")
            {
                timer_add.Stop();
            }
        }
    }
}
