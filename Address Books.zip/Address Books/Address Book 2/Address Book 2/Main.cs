﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Address_Book_2
{
    public partial class Main : Form
    {
        string path = @"Data Source=DIHARA;Initial Catalog=ContactContext;Integrated Security=True";
        SqlConnection con;
        SqlDataAdapter adpt;
        DataTable dt;
        public Main()
        {
            InitializeComponent();
            con = new SqlConnection(path);

            displayAll();
        }

        private void add_Click(object sender, EventArgs e)
        {
            Add_Form addForm = new Add_Form(this);
            addForm.ShowDialog();
        }

        private static bool CheckDatabaseExists(SqlConnection tmpConn, string databaseName)
        {
            string sqlCreateDBQuery;
            bool result = false;

            try
            {
                tmpConn = new SqlConnection("server=DIHARA;Trusted_Connection=yes");

                sqlCreateDBQuery = string.Format("SELECT database_id FROM sys.databases WHERE Name = '{0}'", databaseName);
        
                using (tmpConn)
                {
                    using (SqlCommand sqlCmd = new SqlCommand(sqlCreateDBQuery, tmpConn))
                    {
                        tmpConn.Open();

                        object resultObj = sqlCmd.ExecuteScalar();

                        int databaseID = 0;

                        if (resultObj != null)
                        {
                            int.TryParse(resultObj.ToString(), out databaseID);
                        }

                        tmpConn.Close();

                        result = (databaseID > 0);
                    }
                }
            }
            catch (Exception ex)
            {
                result = false;
            }

            return result;
        }
        public void displayAll()
        {
            if (CheckDatabaseExists(con, "ContactContext"))
            {
                dt = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("select * from Contacts", con);
                adpt.Fill(dt);
                results.DataSource = dt;
                con.Close();
            };
        }

        private void search_bar_KeyUp(object sender, KeyEventArgs e)
        {
            if (CheckDatabaseExists(con, "ContactContext"))
            {
                if (select_search.Text == "Name")
                {
                    dt = new DataTable();
                    con.Open();

                    string typedText = "SELECT * FROM Contacts WHERE ContactName like '" + search_bar.Text + "%'";
                    adpt = new SqlDataAdapter(typedText, con);
                    adpt.Fill(dt);
                    results.DataSource = dt;
                    con.Close();
                }

                if (select_search.Text == "Number")
                {
                    dt = new DataTable();
                    con.Open();

                    string typedText = "SELECT * FROM Contacts WHERE ContactNumber like '" + search_bar.Text + "%'";
                    adpt = new SqlDataAdapter(typedText, con);
                    adpt.Fill(dt);
                    results.DataSource = dt;
                    con.Close();
                }

                if (select_search.Text == "Address")
                {
                    dt = new DataTable();
                    con.Open();

                    string typedText = "SELECT * FROM Contacts WHERE ContactAddress like '" + search_bar.Text + "%'";
                    adpt = new SqlDataAdapter(typedText, con);
                    adpt.Fill(dt);
                    results.DataSource = dt;
                    con.Close();
                }

                if (select_search.Text == "Birthday")
                {
                    dt = new DataTable();
                    con.Open();

                    string typedText = "SELECT * FROM Contacts WHERE ContactBirthday like '" + search_bar.Text + "%'";
                    adpt = new SqlDataAdapter(typedText, con);
                    adpt.Fill(dt);
                    results.DataSource = dt;
                    con.Close();
                }

                if (select_search.Text == "E-Mail")
                {
                    dt = new DataTable();
                    con.Open();

                    string typedText = "SELECT * FROM Contacts WHERE ContactEmail like '" + search_bar.Text + "%'";
                    adpt = new SqlDataAdapter(typedText, con);
                    adpt.Fill(dt);
                    results.DataSource = dt;
                    con.Close();
                }
            }
        }

        private void results_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            string id = results.Rows[e.RowIndex].Cells[0].Value.ToString();
            string name = results.Rows[e.RowIndex].Cells[1].Value.ToString();
            string number = results.Rows[e.RowIndex].Cells[2].Value.ToString();
            string addr = results.Rows[e.RowIndex].Cells[3].Value.ToString();
            string bday = results.Rows[e.RowIndex].Cells[4].Value.ToString();
            string email = results.Rows[e.RowIndex].Cells[5].Value.ToString();

            string[] data = { id, name, number, addr, bday, email };

            if (results.Rows[e.RowIndex].Cells[6].Value.ToString()!="") {

                MemoryStream image = new MemoryStream((byte[])results.Rows[e.RowIndex].Cells[6].Value);

                Edit_Form editForm = new Edit_Form(data, image, this);
                editForm.ShowDialog(); // Shows Form3
            }
            else
            {
                Edit_Form editForm = new Edit_Form(data, this);
                editForm.ShowDialog(); // Shows Form3
            }
            
        }

        private void tree_btn_Click(object sender, EventArgs e)
        {
            Tree_Form treeForm = new Tree_Form();
            treeForm.ShowDialog();
        }
    }
}
