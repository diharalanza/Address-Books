﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Address_Book
{
    public partial class Form2 : Form
    {
        string path = @"Data Source=DIHARA;Initial Catalog=db1;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        Form1 parent;

        public Form2(Form1 par)
        {
            InitializeComponent();
            parent = par;
            con = new SqlConnection(path);

        }

        private void save_button_Click(object sender, EventArgs e)
        {
            bool save = true;

            //checks if all is blank
            if (String.IsNullOrWhiteSpace(name_input.Text) && String.IsNullOrWhiteSpace(number_input.Text) && String.IsNullOrWhiteSpace(address_input.Text) && (String.IsNullOrWhiteSpace(day.Text) || String.IsNullOrWhiteSpace(month.Text) || String.IsNullOrWhiteSpace(year.Text)) && String.IsNullOrWhiteSpace(email_input.Text))
            {
                MessageBox.Show("Please enter atleast one value.");
                save = false;
            }
            else
            {
                if (long.TryParse(month.Text, out _) == false || long.TryParse(day.Text, out _) == false || long.TryParse(year.Text, out _) == false)
                {
                    MessageBox.Show("Enter a valid date.");
                    save = false;
                }
                else if (String.IsNullOrWhiteSpace(day.Text) == false && String.IsNullOrWhiteSpace(month.Text) == false && String.IsNullOrWhiteSpace(year.Text) == false)
                {
                    if ((int.Parse(day.Text) > 31 || int.Parse(day.Text) < 1) || (int.Parse(month.Text) > 12 || int.Parse(month.Text) < 1) || int.Parse(year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date.");
                        save = false;
                    }
                    else if ((int.Parse(day.Text) > 29 || int.Parse(day.Text) < 1) && (int.Parse(month.Text) == 2) || int.Parse(year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date.");
                        save = false;
                    }
                }

                else if (String.IsNullOrWhiteSpace(day.Text) == false || String.IsNullOrWhiteSpace(month.Text) == false || String.IsNullOrWhiteSpace(year.Text) == false)
                {
                    MessageBox.Show("Enter a valid date.");
                    save = false;
                }
            }

            //number is typed in
            if (!(String.IsNullOrWhiteSpace(number_input.Text)))
            {
                if (long.TryParse(number_input.Text, out _) == false)
                {
                    MessageBox.Show("Enter a valid phone number.");
                    save = false;
                }
            }
            if(save == true)
            {
                //con.Open();
                string bday="";
                if (String.IsNullOrWhiteSpace(day.Text) == false) {
                    bday = int.Parse(day.Text) + "/" + int.Parse(month.Text) + "/" + int.Parse(year.Text);
                }

                /*cmd = new SqlCommand("insert into Contact (Contact_Name,Contact_Number,Contact_Address,Contact_Bday,Contact_Email) values ('" + name_input.Text + "','" + number_input.Text + "','" + address_input.Text + "','" + bday + "','" + email_input.Text + "') ", con);
                cmd.ExecuteNonQuery();


                con.Close();
                */

                using (con)
                {
                    con.Open();
                    cmd = new SqlCommand("addContact", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = name_input.Text;
                    cmd.Parameters.AddWithValue("@number", SqlDbType.NVarChar).Value = number_input.Text;
                    cmd.Parameters.AddWithValue("@address", SqlDbType.NVarChar).Value = address_input.Text;
                    cmd.Parameters.AddWithValue("@birthday", SqlDbType.NVarChar).Value = bday;
                    cmd.Parameters.AddWithValue("@email", SqlDbType.NVarChar).Value = email_input.Text;
                    cmd.ExecuteNonQuery();
                    con.Close();
                }

                MessageBox.Show("Contact saved.");
                parent.displayAll();
                this.Close();
            }
        }

    }
}
