﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Address_Book
{
    public partial class Form1 : Form
    { 
        string path = @"Data Source=DIHARA;Initial Catalog=db1;Integrated Security=True";
        SqlConnection con;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlCommand cmd;
        
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection(path);
            displayAll();
        }

        private void add_btn_Click(object sender, EventArgs e)
        {
         
            Form2 f2 = new Form2(this);
            f2.ShowDialog(); // Shows Form2

        }
        
        public void displayAll()
        {
            con.Open();

            cmd = new SqlCommand("showAll", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "showAll";
      
            dt = new DataTable();
            
            adpt = new SqlDataAdapter(cmd);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void search_bar_KeyUp(object sender, KeyEventArgs e)
        {
            /*
            if (select_search.Text == "Name")
            {
                dt = new DataTable();
                con.Open();

                string typedText = "SELECT * FROM Contact WHERE Contact_Name like '" + search_bar.Text + "%'";
                adpt = new SqlDataAdapter(typedText, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }


            if (select_search.Text == "Number")
            {
                dt = new DataTable();
                con.Open();

                string typedText = "SELECT * FROM Contact WHERE Contact_Number like '" + search_bar.Text + "%'";
                adpt = new SqlDataAdapter(typedText, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }

            if (select_search.Text == "Address")
            {
                dt = new DataTable();
                con.Open();

                string typedText = "SELECT * FROM Contact WHERE Contact_Address like '" + search_bar.Text + "%'";
                adpt = new SqlDataAdapter(typedText, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }


            if (select_search.Text == "Birthday")
            {
                dt = new DataTable();
                con.Open();

                string typedText = "SELECT * FROM Contact WHERE Contact_Bday like '" + search_bar.Text + "%'";
                adpt = new SqlDataAdapter(typedText, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }

            if (select_search.Text == "E-Mail")
            {
                dt = new DataTable();
                con.Open();

                string typedText = "SELECT * FROM Contact WHERE Contact_Email like '" + search_bar.Text + "%'";
                adpt = new SqlDataAdapter(typedText, con);
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            */

            con.Open();

            cmd = new SqlCommand("find", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "find";
            cmd.Parameters.AddWithValue("@value", SqlDbType.VarChar).Value = select_search.Text;
            cmd.Parameters.AddWithValue("@search", SqlDbType.VarChar).Value = search_bar.Text;

            dt = new DataTable();

            adpt = new SqlDataAdapter(cmd);
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void showall_btn_Click(object sender, EventArgs e)
        {
            displayAll();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            string name = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            string number = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            string addr = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            string bday = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            string email = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();

            string[] data = { id, name, number, addr, bday, email}; 
            Form3 f3 = new Form3(data, this);
            f3.ShowDialog(); // Shows Form3
        }
    }
}
