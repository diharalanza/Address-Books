﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Address_Book
{
    public partial class Form3 : Form
    {
        string path = @"Data Source=DIHARA;Initial Catalog=db1;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        string id;
        Form1 parent;
        public Form3(string[] value, Form1 par)
        {
            InitializeComponent();
            con = new SqlConnection(path);

            parent = par;

            id = value[0];

            edit_name.Text = value[1];
            edit_num.Text = value[2];
            edit_addr.Text = value[3];

            if (!String.IsNullOrWhiteSpace(value[4]))
            {
                string[] bday_vals = value[4].Split('/');

                day.Text = bday_vals[0];
                month.Text = bday_vals[1];
                year.Text = bday_vals[2];
            }

            edit_email.Text = value[5];
            
        }

        private void upd_btn_Click(object sender, EventArgs e)
        {
            bool save = true;

            //checks if all is blank
            if (String.IsNullOrWhiteSpace(edit_name.Text) && String.IsNullOrWhiteSpace(edit_num.Text) && String.IsNullOrWhiteSpace(edit_addr.Text) && (String.IsNullOrWhiteSpace(day.Text) || String.IsNullOrWhiteSpace(month.Text) || String.IsNullOrWhiteSpace(year.Text)) && String.IsNullOrWhiteSpace(edit_email.Text))
            {
                MessageBox.Show("Please enter atleast one value.");
                save = false;
            }
            else
            {
                if (long.TryParse(month.Text, out _) == false || long.TryParse(day.Text, out _) == false || long.TryParse(year.Text, out _) == false)
                {
                    MessageBox.Show("Enter a valid date.");
                    save = false;
                }

                else if (String.IsNullOrWhiteSpace(day.Text) == false && String.IsNullOrWhiteSpace(month.Text) == false && String.IsNullOrWhiteSpace(year.Text) == false)
                {
                    if ((int.Parse(day.Text) > 31 || int.Parse(day.Text) < 1) || (int.Parse(month.Text) > 12 || int.Parse(month.Text) < 1) || int.Parse(year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date.");
                        save = false;
                    }
                    else if ((int.Parse(day.Text) > 29 || int.Parse(day.Text) < 1) && (int.Parse(month.Text) == 2) || int.Parse(year.Text) < 1)
                    {
                        MessageBox.Show("Enter a valid date.");
                        save = false;
                    }
                }

                else if (String.IsNullOrWhiteSpace(day.Text) == false || String.IsNullOrWhiteSpace(month.Text) == false || String.IsNullOrWhiteSpace(year.Text) == false)
                {
                    MessageBox.Show("Enter a valid date.");
                    save = false;
                }
            }

            //number is typed in
            if (!(String.IsNullOrWhiteSpace(edit_num.Text)))
            {
                if (long.TryParse(edit_num.Text, out _) == false)
                {
                    MessageBox.Show("Enter a valid phone number.");
                    save = false;
                }
            }
            if (save == true)
            {
                //con.Open();
                string bday = "";
                if (String.IsNullOrWhiteSpace(day.Text) == false)
                {
                    bday = int.Parse(day.Text) + "/" + int.Parse(month.Text) + "/" + int.Parse(year.Text);
                }

                /*cmd = new SqlCommand("update contact set Contact_Name='" + edit_name.Text + "', Contact_Number='" + edit_num.Text + "', Contact_Address='" + edit_addr.Text + "', Contact_Bday='" + bday + "', Contact_Email='" + edit_email.Text + "' where Contact_Id = '" + id + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Contact updated.");
                parent.displayAll();

                this.Close();
                */

                using (con)
                {
                    con.Open();
                    cmd = new SqlCommand("editContact", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = int.Parse(id);
                    cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = edit_name.Text;
                    cmd.Parameters.AddWithValue("@number", SqlDbType.VarChar).Value = edit_num.Text;
                    cmd.Parameters.AddWithValue("@address", SqlDbType.VarChar).Value = edit_addr.Text;
                    cmd.Parameters.AddWithValue("@birthday", SqlDbType.VarChar).Value = bday;
                    cmd.Parameters.AddWithValue("@email", SqlDbType.VarChar).Value = edit_email.Text;

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Contact updated.");
                    parent.displayAll();

                    this.Close();

                }                
            }
        }

        private void del_btn_Click(object sender, EventArgs e)
        {
            using (con)
            {
                con.Open();
                cmd = new SqlCommand("deleteContact", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = int.Parse(id);
 
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Contact deleted.");
                parent.displayAll();

                this.Close();

            }
           
        }
    }
}
