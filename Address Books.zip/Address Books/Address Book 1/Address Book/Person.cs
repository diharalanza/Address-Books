﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Address_Book
{
    public class Person
    {
        public string name;
        public string number;
        public string address;

        public int day;
        public int month;
        public long year;

        public string email;

        public Person(string n, string num, string addr, int d, int m, long y, string e)
        {
            name = n;
            number = num;
            address = addr;
            day = d;
            month = m;
            year = y;
            email = e;
        }

    }
}
