﻿
namespace Address_Book
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.edit_name = new System.Windows.Forms.TextBox();
            this.edit_email = new System.Windows.Forms.TextBox();
            this.edit_addr = new System.Windows.Forms.TextBox();
            this.edit_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.del_btn = new System.Windows.Forms.Button();
            this.upd_btn = new System.Windows.Forms.Button();
            this.year = new System.Windows.Forms.TextBox();
            this.month = new System.Windows.Forms.TextBox();
            this.day = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // edit_name
            // 
            this.edit_name.Location = new System.Drawing.Point(89, 12);
            this.edit_name.Name = "edit_name";
            this.edit_name.Size = new System.Drawing.Size(277, 23);
            this.edit_name.TabIndex = 0;
            // 
            // edit_email
            // 
            this.edit_email.Location = new System.Drawing.Point(154, 128);
            this.edit_email.Name = "edit_email";
            this.edit_email.Size = new System.Drawing.Size(212, 23);
            this.edit_email.TabIndex = 1;
            this.edit_email.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // edit_addr
            // 
            this.edit_addr.Location = new System.Drawing.Point(89, 41);
            this.edit_addr.Name = "edit_addr";
            this.edit_addr.Size = new System.Drawing.Size(277, 23);
            this.edit_addr.TabIndex = 3;
            // 
            // edit_num
            // 
            this.edit_num.Location = new System.Drawing.Point(154, 70);
            this.edit_num.Name = "edit_num";
            this.edit_num.Size = new System.Drawing.Size(212, 23);
            this.edit_num.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(94, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Birthday (dd/mm/yy):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(104, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "E-Mail:";
            // 
            // del_btn
            // 
            this.del_btn.Location = new System.Drawing.Point(268, 167);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(75, 23);
            this.del_btn.TabIndex = 10;
            this.del_btn.Text = "Delete";
            this.del_btn.UseVisualStyleBackColor = true;
            this.del_btn.Click += new System.EventHandler(this.del_btn_Click);
            // 
            // upd_btn
            // 
            this.upd_btn.Location = new System.Drawing.Point(187, 167);
            this.upd_btn.Name = "upd_btn";
            this.upd_btn.Size = new System.Drawing.Size(75, 23);
            this.upd_btn.TabIndex = 11;
            this.upd_btn.Text = "Update";
            this.upd_btn.UseVisualStyleBackColor = true;
            this.upd_btn.Click += new System.EventHandler(this.upd_btn_Click);
            // 
            // year
            // 
            this.year.ForeColor = System.Drawing.Color.Black;
            this.year.Location = new System.Drawing.Point(274, 99);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(92, 23);
            this.year.TabIndex = 16;
            // 
            // month
            // 
            this.month.ForeColor = System.Drawing.Color.Black;
            this.month.Location = new System.Drawing.Point(214, 99);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(54, 23);
            this.month.TabIndex = 15;
            // 
            // day
            // 
            this.day.ForeColor = System.Drawing.Color.Black;
            this.day.Location = new System.Drawing.Point(154, 99);
            this.day.Name = "day";
            this.day.Size = new System.Drawing.Size(54, 23);
            this.day.TabIndex = 14;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 202);
            this.Controls.Add(this.year);
            this.Controls.Add(this.month);
            this.Controls.Add(this.day);
            this.Controls.Add(this.upd_btn);
            this.Controls.Add(this.del_btn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.edit_num);
            this.Controls.Add(this.edit_addr);
            this.Controls.Add(this.edit_email);
            this.Controls.Add(this.edit_name);
            this.Name = "Form3";
            this.Text = "Edit or Delete Contact";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox edit_name;
        private System.Windows.Forms.TextBox edit_email;
        private System.Windows.Forms.TextBox edit_addr;
        private System.Windows.Forms.TextBox edit_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button del_btn;
        private System.Windows.Forms.Button upd_btn;
        private System.Windows.Forms.TextBox year;
        private System.Windows.Forms.TextBox month;
        private System.Windows.Forms.TextBox day;
    }
}